function sayHello() {
  const name = document.getElementById("name").value;
  alert("Xin chào, " + name);
}
