document.getElementById("btnHello").addEventListener("click", function() {
  const name = document.getElementById("name").value.trim();
  
  if (name) {
    alert("Xin chào, " + name);
  } else {
    alert("Vui lòng nhập tên!");
  }
});
