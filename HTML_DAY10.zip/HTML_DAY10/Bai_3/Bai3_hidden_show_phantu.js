function anVan() {
  document.getElementById("doanvan").style.display = "none";
}

function hienVan() {
  document.getElementById("doanvan").style.display = "block";
}